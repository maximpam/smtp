<?php
$start = microtime(true);
// Without Composer (and instead of "require 'vendor/autoload.php'"):
/*require("sendpulse-rest-api-php/src/ApiInterface.php");
require("sendpulse-rest-api-php/src/ApiClient.php");
require("sendpulse-rest-api-php/src/Storage/TokenStorageInterface.php");
require("sendpulse-rest-api-php/src/Storage/FileStorage.php");
require("sendpulse-rest-api-php/src/Storage/SessionStorage.php");
require("sendpulse-rest-api-php/src/Storage/MemcachedStorage.php");
require("sendpulse-rest-api-php/src/Storage/MemcacheStorage.php");*/

require("sendpulse-rest-api-php/src/Storage/TokenStorageInterface.php");
require("sendpulse-rest-api-php/src/Storage/FileStorage.php");
require("sendpulse-rest-api-php/src/ApiInterface.php");
require("sendpulse-rest-api-php/src/ApiClient.php");


use Sendpulse\RestApi\ApiClient;
use Sendpulse\RestApi\Storage\FileStorage;

// API credentials from https://login.sendpulse.com/settings/#api
define('API_USER_ID', '198b0ec2db2690e1a4f9323cd7f1d512');
define('API_SECRET', '62c3a374263402f72eda46c9e41d471e');

$SPApiClient = new ApiClient(API_USER_ID, API_SECRET, new FileStorage());

$campaigns = [
    15216203,
    15216205,
    15216206,
    15312686,
    15452037,
    15452038,
    15452039,
    15452040
];


$date = date("F j, Y, g:i a");

$totalSent = 0;

file_put_contents( 'stats.txt', PHP_EOL. $date .PHP_EOL, FILE_APPEND );

file_put_contents( 'stats.txt', '1st Day Cohort' .PHP_EOL , FILE_APPEND );

foreach ($campaigns as $key){
   $result = $SPApiClient->getPushCampaignStat($key);
   $text = 'Campaign_ID:' . $result->id . PHP_EOL
       . 'Sent:' . $result->send . PHP_EOL;
   $totalSent+=$result->send;

   file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//2nd day

file_put_contents( 'stats.txt', '2nd Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [
    15216684,
    15216685,
    15216686,
    15216687,
    15312710,
    15343013,
    15452061,
    15452062
];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );
//3rd day

file_put_contents( 'stats.txt', '3rd Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15217175,15217176,15217177,15217178,15312768,15343345,15452391,15452392];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//4th day

file_put_contents( 'stats.txt', '4th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15218025,15218026,15218027,15218028,15312796,15343385,15451661,15451662];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//5th day

file_put_contents( 'stats.txt', '5th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15218167,15218168,15218169,15218170,15312813,15343425,15451925,15452020];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//6th day

file_put_contents( 'stats.txt', '6th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15219453,15219454,15219455,15219456,15312829,15452514,15452515,15452516];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//7th day

file_put_contents( 'stats.txt', '7th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15224426,15224427,15224428,15224429,15312863,15452652,15452653,15452654];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//8th day

file_put_contents( 'stats.txt', '8th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15225018,15225019,15225020,15225021,15312870,15452703,15452704,15452705];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );


//20th day

file_put_contents( 'stats.txt', '20th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15226067,15480172,15480174,15480175,15480177,15480178,15480179,15480180];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//21st day

file_put_contents( 'stats.txt', '21st Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15271046,15480527,15480528,15480529,15480531,15480532,15480533,15480534];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//22nd day

file_put_contents( 'stats.txt', '22nd Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15271062,15480643,15480644,15480645,15480646,15480647,15480648,15480649];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//23rd day

file_put_contents( 'stats.txt', '23rd Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15271077,15480694,15480695,15480770,15480771,15480772,15480773,15480774];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//24th day

file_put_contents( 'stats.txt', '24th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15271095,15482155,15482156,15482157,15482158,15482159,15482184,15482185];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//25th day

file_put_contents( 'stats.txt', '25th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15271109,15482486,15482487,15482488,15482489,15482490,15482491,15482492];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//26th day

file_put_contents( 'stats.txt', '26th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15271120,15482803,15482804,15482806,15482807,15482808,15482809,15482810];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//27th day

file_put_contents( 'stats.txt', '27th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15271130,15483002,15483003,15483004,15483005,15483006,15483007,15483008];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//40th day

file_put_contents( 'stats.txt', '40th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15332274,15681383,15681384,15681385,15681386,15681387,15681388,15681389];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//41st day

file_put_contents( 'stats.txt', '41st Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15332305,15681677,15681678,15681679,15681680,15681681,15681682,15681692];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//42nd day

file_put_contents( 'stats.txt', '42nd Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15344164,15681903,15681904,15681905,15681906,15681907,15681908,15681909];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//43rd day

file_put_contents( 'stats.txt', '43rd Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15344179,15682597,15682599,15682600,15682601,15682602,15682604,15682605];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//44th day

file_put_contents( 'stats.txt', '44th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15344190,15682794,15682795,15682796,15682797,15682798,15682799,15682800];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//45th day

file_put_contents( 'stats.txt', '45th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15344196,15683039,15683040,15683041,15683042,15683043,15683044,15683045];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//46th day

file_put_contents( 'stats.txt', '46th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15344214,15683214,15683215,15683216,15683217,15683218,15683219,15683220];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//50th day

file_put_contents( 'stats.txt', '50th Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15673778,15683694,15683695,15683697,15683698,15683699,15683700,15683701];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//51st day

file_put_contents( 'stats.txt', '51st Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15673898,16146369,16146370,16146372,16146373,16146374,16146376,16146377];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//52nd day

file_put_contents( 'stats.txt', '52nd Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15674708,16147164,16147165,16147166,16147167,16147168,16147169,16147170];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

//53rd day

file_put_contents( 'stats.txt', '53rd Day Cohort' .PHP_EOL , FILE_APPEND );

$campaigns = [15902063,15902064,16154020,16154021,16154022,16154023,16154024,16154025];
$totalSent = 0;

foreach ($campaigns as $key){
    $result = $SPApiClient->getPushCampaignStat($key);
    $text = 'Campaign_ID:' . $result->id . PHP_EOL
        . 'Sent:' . $result->send . PHP_EOL;
    $totalSent+=$result->send;

    file_put_contents( 'stats.txt', $text , FILE_APPEND );

}

file_put_contents( 'stats.txt', 'Totally sent: '. $totalSent .PHP_EOL , FILE_APPEND );

file_put_contents( 'stats.txt', '________________________________________' .PHP_EOL , FILE_APPEND );

echo "true";
//var_dump($result);
echo 'Время выполнения скрипта: '.round(microtime(true) - $start, 4).' сек.';



?>

